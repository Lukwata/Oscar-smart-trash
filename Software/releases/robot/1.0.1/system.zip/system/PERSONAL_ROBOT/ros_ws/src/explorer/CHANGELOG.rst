^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package explorer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* Deleted deprecated file
* Added dynamic naming of robots
* Contributors: Neuhold Daniel, Torsten Andre

0.1.6 (2015-01-08)
------------------
* Fixed linking error in explorer
* Removed residual manifest.xml
* Update package.xml
  author
* Update package.xml
  adding author and email
* Contributors: Torsten Andre, dneuhold

0.1.5 (2014-12-10)
------------------
* Fixed compilation error map_merger
* Contributors: Torsten Andre

0.1.4 (2014-12-02)
------------------
* Further updates
* Added authors for packages.
* Contributors: Torsten Andre
