#!/bin/bash
rosbag record -a -O $1
