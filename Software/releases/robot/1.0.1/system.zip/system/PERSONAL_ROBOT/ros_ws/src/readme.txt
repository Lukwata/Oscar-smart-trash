#to edit respwan mobile_base
# roscd turtlebot_bringup  launch/include/kobuki/mobile_base_launch.yml...

#to edit turtlebot bring up minimal
# remove all data, rapp didnt in launch/minimal.launch
# edit velocity max in :
 roscd turtlebot_bringup , cd params/default/smooth.yml
