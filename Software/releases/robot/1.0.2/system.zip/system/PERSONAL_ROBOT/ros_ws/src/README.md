Ros packages
=======

https://docs.google.com/document/d/1Uhwlg3SbaAKVKbN8JzktlJbuaWmXEDLtgBTQa4r2abU/edit </br>
Part 4: install navi service </br>
IV.1)  </br>
ROS apt-get </br>
sudo apt-get install ros-indigo-kobuki </br>
sudo apt-get install ros-indigo-turtlebot-bringup </br>
sudo apt-get install ros-indigo-common-tutorials </br>
sudo apt-get install ros-indigo-navigation </br>
sudo apt-get install ros-indigo-joy </br>
sudo apt-get install ros-indigo-compressed-depth-image-transport </br>

IV.2) </br>
Roswork_sr: </br>
Kobuki_msgs </br>
Navigation_msgs </br>
Navi_services </br>
Pr_teleop </br>
Turtlebot </br>
Usb config </br>
rosrun kobuki_ftdi create_udev_rules 

