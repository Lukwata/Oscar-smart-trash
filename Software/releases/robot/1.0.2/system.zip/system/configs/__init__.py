# utility functions on top of zeromq

