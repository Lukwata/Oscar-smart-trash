#SERVER = "tcp://*" # run on server
SERVER = "tcp://52.3.101.47" # run on client
#SERVER = "tcp://127.0.0.1"

LOCAL = "ipc:///tmp"
