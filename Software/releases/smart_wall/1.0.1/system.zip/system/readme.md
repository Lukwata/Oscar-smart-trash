#path OS config
[~/aos/system/configs/channel.py](https://github.com/duyhtq/maya/blob/develop/aos/system/configs/channel.py)

go to line:

`CURRENT_DEVICE = AUTONOMOUS_DEVICE.PERSONAL_ROBOT`

and edit device type you want.

with list [`AUTONOMOUS_DEVICE`](https://github.com/duyhtq/maya/blob/develop/aos/system/configs/device.py) :

`SMART_DESK`
`SMART_DESK_C`
`SMART_WALL`
`PERSONAL_ROBOT`
`CLONE`
`TELE_PORT`
`DRONE`
