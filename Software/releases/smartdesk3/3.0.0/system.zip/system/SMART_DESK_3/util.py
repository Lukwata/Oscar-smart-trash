

def get_speaker_hwindex():
    return 0


def get_speaker_name():
    return "PCM"


def play_sound(path):
    pass

